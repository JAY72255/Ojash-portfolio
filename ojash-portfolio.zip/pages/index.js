import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";

export default function Home() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    gsap.from(".animate-fade-in", { opacity: 0, y: 50, duration: 1, ease: "power2.out" });
  }, []);

  return (
    <div className={darkMode ? "dark bg-gray-900 text-white" : "bg-gray-100 text-gray-900"}>
      <header className="text-center p-10 bg-gray-800 text-white">
        <h1 className="text-4xl font-bold">Ojash Mishra</h1>
        <p className="text-lg">Aspiring Web Developer & Digital Creator</p>
        <button
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
          onClick={() => setDarkMode(!darkMode)}
        >
          Toggle Dark Mode
        </button>
      </header>

      <section className="container mx-auto p-6 animate-fade-in">
        <h2 className="text-3xl font-semibold text-center">About Me</h2>
        <p className="text-center mt-4">
          I am a passionate web developer with expertise in HTML, CSS, JavaScript, SQL, and PHP. 
          Currently pursuing BCA from Awadhesh Pratap Singh University, Rewa.
        </p>
      </section>

      <section className="container mx-auto p-6 animate-fade-in">
        <h2 className="text-3xl font-semibold text-center">Skills</h2>
        <div className="flex flex-wrap justify-center gap-4 mt-4">
          {["HTML", "CSS", "JavaScript", "SQL", "PHP", "React.js"].map((skill, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.1 }}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg shadow-md"
            >
              {skill}
            </motion.div>
          ))}
        </div>
      </section>

      <section className="container mx-auto p-6 animate-fade-in">
        <h2 className="text-3xl font-semibold text-center">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
          {["NIMCET Test Series", "Online Learning Platform"].map((project, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.05 }}
              className="bg-gray-800 text-white p-6 rounded-lg shadow-lg"
            >
              <h3 className="text-xl font-semibold">{project}</h3>
              <p className="mt-2">A modern project to enhance learning experience.</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="container mx-auto p-6 text-center animate-fade-in">
        <h2 className="text-3xl font-semibold">Contact</h2>
        <p>Email: <a href="mailto:ojashmishra728@gmail.com" className="text-blue-500">ojashmishra728@gmail.com</a></p>
        <p>Phone: +91 8718041568</p>
      </section>
    </div>
  );
}
